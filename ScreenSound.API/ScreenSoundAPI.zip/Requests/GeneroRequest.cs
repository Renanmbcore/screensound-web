namespace ScreenSound.API.Requests;

public record GeneroRequest(string Nome, string Descricao);